package com.tokiplayer

import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import androidx.media3.common.MediaItem as ExoMediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.recyclerview.widget.RecyclerView
import com.tokiplayer.databinding.ItemMediaBinding

class MediaPagerAdapter(
    private val items: List<MediaItem>,
    private val onLongPress: (MediaItem) -> Unit
) : RecyclerView.Adapter<MediaPagerAdapter.Holder>() {

    private val activePlayers = mutableMapOf<Int, ExoPlayer>()

    inner class Holder(val binding: ItemMediaBinding) : RecyclerView.ViewHolder(binding.root) {
        var player: ExoPlayer? = null
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder =
        Holder(ItemMediaBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun getItemCount() = items.size

    override fun onBindViewHolder(holder: Holder, position: Int) {
        val item = items[position]
        holder.binding.mediaName.text = item.name
        holder.binding.playerView.visibility =
            if (item.mimeType.startsWith("video")) View.VISIBLE else View.INVISIBLE

        val root = holder.binding.root
        var downAt = 0L
        root.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downAt = System.currentTimeMillis()
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (System.currentTimeMillis() - downAt >= 550) {
                        onLongPress(item)
                    }
                    true
                }
                else -> true
            }
        }
    }

    fun start(position: Int, context: android.content.Context) {
        val holder = (RecyclerView.ViewHolder::class.java)
        // Playback is managed by MainActivity through visible-holder callbacks.
    }

    override fun onViewRecycled(holder: Holder) {
        holder.player?.release()
        holder.player = null
        super.onViewRecycled(holder)
    }
}
