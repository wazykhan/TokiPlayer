package com.tokiplayer

import android.content.ContentResolver
import android.content.Context
import android.provider.MediaStore

object MediaRepository {
    fun scan(context: Context): List<MediaItem> {
        val resolver = context.contentResolver
        val result = mutableListOf<MediaItem>()
        scanCollection(resolver, MediaStore.Video.Media.EXTERNAL_CONTENT_URI, result, true)
        scanCollection(resolver, MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, result, false)
        return result.sortedBy { it.name.lowercase() }
    }

    private fun scanCollection(
        resolver: ContentResolver,
        collection: android.net.Uri,
        result: MutableList<MediaItem>,
        video: Boolean
    ) {
        val projection = arrayOf(
            MediaStore.MediaColumns._ID,
            MediaStore.MediaColumns.DISPLAY_NAME,
            MediaStore.MediaColumns.MIME_TYPE,
            MediaStore.MediaColumns.DURATION
        )
        resolver.query(
            collection,
            projection,
            null,
            null,
            MediaStore.MediaColumns.DATE_ADDED + " DESC"
        )?.use { c ->
            val id = c.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
            val name = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
            val mime = c.getColumnIndexOrThrow(MediaStore.MediaColumns.MIME_TYPE)
            val duration = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DURATION)
            while (c.moveToNext()) {
                val mediaUri = android.content.ContentUris.withAppendedId(collection, c.getLong(id))
                result += MediaItem(
                    mediaUri,
                    c.getString(name) ?: "Unknown",
                    c.getString(mime) ?: if (video) "video/*" else "audio/*",
                    c.getLong(duration)
                )
            }
        }
    }
}
