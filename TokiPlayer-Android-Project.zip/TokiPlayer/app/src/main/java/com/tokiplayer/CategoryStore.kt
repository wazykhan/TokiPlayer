package com.tokiplayer

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class CategoryStore(context: Context) {
    private val prefs = context.getSharedPreferences("categories", Context.MODE_PRIVATE)

    fun categories(): List<String> =
        prefs.getStringSet("names", emptySet())!!.toList().sorted()

    fun addCategory(name: String) {
        val clean = name.trim()
        if (clean.isEmpty()) return
        val set = prefs.getStringSet("names", emptySet())!!.toMutableSet()
        set.add(clean)
        prefs.edit().putStringSet("names", set).apply()
    }

    fun addToCategory(category: String, uri: String) {
        val key = "items_$category"
        val set = prefs.getStringSet(key, emptySet())!!.toMutableSet()
        set.add(uri)
        prefs.edit().putStringSet(key, set).apply()
    }

    fun items(category: String): Set<String> =
        prefs.getStringSet("items_$category", emptySet()) ?: emptySet()
}
