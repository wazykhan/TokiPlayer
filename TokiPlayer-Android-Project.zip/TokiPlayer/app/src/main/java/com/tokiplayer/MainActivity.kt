package com.tokiplayer

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.EditText
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem as ExoMediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.viewpager2.widget.ViewPager2
import com.tokiplayer.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var store: CategoryStore
    private var media = emptyList<MediaItem>()
    private var currentPlayer: ExoPlayer? = null
    private var currentPosition = -1

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            if (hasMediaPermission()) loadMedia() else showPermissionMessage()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        store = CategoryStore(this)
        requestMediaPermission()
    }

    private fun hasMediaPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= 33) {
            ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_VIDEO) == PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_AUDIO) == PackageManager.PERMISSION_GRANTED
        } else {
            ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
        }
    }

    private fun requestMediaPermission() {
        if (hasMediaPermission()) loadMedia() else {
            val permissions = if (Build.VERSION.SDK_INT >= 33)
                arrayOf(Manifest.permission.READ_MEDIA_VIDEO, Manifest.permission.READ_MEDIA_AUDIO)
            else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
            permissionLauncher.launch(permissions)
        }
    }

    private fun loadMedia() {
        Thread {
            val result = MediaRepository.scan(this)
            runOnUiThread {
                media = result
                binding.count.text = "${media.size} files"
                if (media.isEmpty()) {
                    binding.empty.visibility = android.view.View.VISIBLE
                    binding.pager.visibility = android.view.View.GONE
                    return@runOnUiThread
                }
                binding.empty.visibility = android.view.View.GONE
                binding.pager.visibility = android.view.View.VISIBLE
                binding.pager.adapter = MediaPagerAdapter(media) { showCategoryDialog(it) }
                binding.pager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
                    override fun onPageSelected(position: Int) {
                        play(position)
                    }
                })
                binding.pager.setCurrentItem(0, false)
            }
        }.start()
    }

    private fun play(position: Int) {
        if (position !in media.indices || position == currentPosition) return
        currentPlayer?.release()
        currentPlayer = null
        currentPosition = position

        val holder = (binding.pager.getChildAt(0) as? androidx.recyclerview.widget.RecyclerView)
            ?.findViewHolderForAdapterPosition(position) ?: return
        val playerView = holder.itemView.findViewById<PlayerView>(com.tokiplayer.R.id.playerView)
        val item = media[position]
        val player = ExoPlayer.Builder(this).build()
        player.setMediaItem(ExoMediaItem.fromUri(item.uri))
        player.repeatMode = ExoPlayer.REPEAT_MODE_ONE
        player.prepare()
        player.playWhenReady = true
        playerView.player = player
        currentPlayer = player
    }

    private fun showCategoryDialog(item: MediaItem) {
        val names = store.categories().toMutableList()
        names.add("+ Create new category")
        AlertDialog.Builder(this)
            .setTitle("Add to category")
            .setItems(names.toTypedArray()) { _, which ->
                if (which == names.lastIndex) createCategory(item)
                else {
                    store.addToCategory(names[which], item.uri.toString())
                    Toast.makeText(this, "Added to ${names[which]}", Toast.LENGTH_SHORT).show()
                }
            }
            .show()
    }

    private fun createCategory(item: MediaItem) {
        val input = EditText(this)
        input.hint = "Category name"
        AlertDialog.Builder(this)
            .setTitle("Create category")
            .setView(input)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Create") { _, _ ->
                val name = input.text.toString().trim()
                if (name.isNotEmpty()) {
                    store.addCategory(name)
                    store.addToCategory(name, item.uri.toString())
                    Toast.makeText(this, "Added to $name", Toast.LENGTH_SHORT).show()
                }
            }
            .show()
    }

    private fun showPermissionMessage() {
        binding.empty.text = "Media permission is required to scan local audio and video."
        binding.empty.visibility = android.view.View.VISIBLE
    }

    override fun onStop() {
        currentPlayer?.release()
        currentPlayer = null
        super.onStop()
    }
}
