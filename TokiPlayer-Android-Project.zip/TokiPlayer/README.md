# TokiPlayer

TokiPlayer is a local-media Android player with a TikTok-style vertical feed.

## Current MVP
- Scans local audio and video using MediaStore
- Vertical swipe feed using ViewPager2
- Auto-play for visible media
- Long press to add media to categories
- Create categories and persist them locally
- Media3/ExoPlayer playback

## Build
Open this project in Android Studio with JDK 17+ and allow Gradle to download dependencies.
Then run:
`./gradlew assembleDebug`

APK:
`app/build/outputs/apk/debug/app-debug.apk`
